import streamlit as st
import time
import numpy as np
from PIL import Image

st.set_page_config(page_title="About us", page_icon="E")

st.markdown("# About Us")
# st.sidebar.header("About Us")
# image = Image.open('About_Us_Image.png')

image = Image.open('Header_Image.png')
st.image(image, caption='Empowering Change, Reducing Methane')
image = Image.open('About_Us_Image.png')
st.image(image, caption='Meet the team')

st.markdown("The Clear R Methane Detection Project brings together a team of six dedicated individuals committed to addressing the urgent challenge of methane emissions. Their collective expertise and passion for environmental sustainability drive their efforts to develop innovative solutions for accurate and efficient methane detection. Through the integration of advanced technologies and data analytics, the team aims to enhance monitoring capabilities and mitigate the impact of methane, a potent greenhouse gas, on climate change. The project's primary objectives include developing a portable methane detection device, optimizing data collection and analysis methods, and collaborating with industry stakeholders to promote widespread adoption of effective mitigation strategies. By combining their diverse skill sets and unwavering commitment to environmental stewardship, the Clear R team strives to make a significant impact in reducing methane emissions and promoting a sustainable future.")